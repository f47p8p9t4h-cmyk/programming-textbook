const pages = [...document.querySelectorAll(".page")];
const counter = document.getElementById("counter");
const toc = document.getElementById("toc");
let current = 0;

function showPage(index) {
  if (index < 0) index = 0;
  if (index >= pages.length) index = pages.length - 1;
  current = index;
  pages.forEach((page, i) => {
    page.classList.toggle("active", i === current);
  });
  counter.textContent = `${current + 1} / ${pages.length}`;
}

function nextPage() {
  if (current < pages.length - 1) showPage(current + 1);
}

function previousPage() {
  if (current > 0) showPage(current - 1);
}

document.getElementById("tocBtn").addEventListener("click", () => {
  toc.classList.add("open");
});

document.getElementById("closeToc").addEventListener("click", () => {
  toc.classList.remove("open");
});

document.getElementById("homeBtn").addEventListener("click", () => {
  showPage(0);
  toc.classList.remove("open");
});

document.querySelectorAll("[data-page]").forEach(button => {
  button.addEventListener("click", () => {
    showPage(Number(button.dataset.page));
    toc.classList.remove("open");
  });
});

document.querySelectorAll("[data-go]").forEach(button => {
  button.addEventListener("click", () => showPage(Number(button.dataset.go)));
});

document.addEventListener("keydown", (event) => {
  if (event.key === "ArrowRight" || event.key === " ") nextPage();
  if (event.key === "ArrowLeft") previousPage();
  if (event.key === "Escape") toc.classList.remove("open");
});

// Беттің оң/сол жағын басу арқылы ауыстыру.
document.getElementById("book").addEventListener("click", (event) => {
  if (event.target.closest("button, a, code, pre")) return;
  const rect = event.currentTarget.getBoundingClientRect();
  const x = event.clientX - rect.left;
  if (x > rect.width * 0.55) nextPage();
  else if (x < rect.width * 0.45) previousPage();
});

showPage(0);
